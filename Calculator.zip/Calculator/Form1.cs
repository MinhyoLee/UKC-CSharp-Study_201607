﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;


namespace Calculator
{
    public partial class Form1 : Form
    {
        string txtString;
        string memoryString;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            textBox1.Text = "";
            txtString = String.Empty;
            memoryString = String.Empty;
            //int x;
            //int y;
        }

        //private void btnNumber_Click(object sender, EventArgs e)
        //{
        //    Button btnName = sender as Button;

        //    #region 버튼 클릭시 해당 문자열 txtString 저장

        //    if (btnName == btnNum1)
        //    {
        //        textBox1.Text += "1";
        //    }
        //    else if (btnName == btnNum2)
        //    {
        //        textBox1.Text += "2";
        //    }
        //    else if (btnName == btnNum3)
        //    {
        //        textBox1.Text += "3";
        //    }
        //    else if (btnName == btnNum4)
        //    {
        //        textBox1.Text += "4";
        //    }
        //    else if (btnName == btnNum5)
        //    {
        //        textBox1.Text += "5";
        //    }
        //    else if (btnName == btnNum6)
        //    {
        //        textBox1.Text += "6";
        //    }
        //    else if (btnName == btnNum7)
        //    {
        //        textBox1.Text += "7";
        //    }
        //    else if (btnName == btnNum8)
        //    {
        //        textBox1.Text += "8";
        //    }
        //    else if (btnName == btnNum9)
        //    {
        //        textBox1.Text += "9";
        //    }
        //    else if (btnName == btnNum0)
        //    {
        //        textBox1.Text += "0";
        //    }
        //    else if (btnName == btnPlusMinus)
        //    {
        //        double dbtxt;

        //        dbtxt = Convert.ToDouble(textBox1.Text);

        //        if (dbtxt > 0)
        //            textBox1.Text += textBox1.Text;
        //        else
        //            textBox1.Text += "-" + textBox1.Text;
        //    }
        //    else if (btnName == btnSqrt)
        //    {
        //        double dbtxt;
        //        double dbtxt_result;

        //        dbtxt = Convert.ToDouble(textBox1.Text);
        //        dbtxt_result = Math.Sqrt(dbtxt);

        //        textBox1.Text += Convert.ToString(dbtxt_result);
        //    }
        //    else if (btnName == btnPercent)
        //    {
        //        double dbtxt;

        //        dbtxt = Convert.ToDouble(textBox1.Text);
        //        dbtxt *= dbtxt * 0.01;

        //        textBox1.Text += Convert.ToString(dbtxt);
        //    }
        //    else if (btnName == btnbunsu)
        //    {
        //        double dbtxt;

        //        dbtxt = Convert.ToDouble(textBox1.Text);
        //        dbtxt = 1 / dbtxt;

        //        textBox1.Text += Convert.ToString(dbtxt);
        //    }

        //    #endregion

        //    txtString += textBox1;
        //}

        #region 버튼 클릭 시 textbox, 해당 문자열 저장

        private void btnNum1_Click(object sender, EventArgs e)
        {
            textBox1.Text += "1";
            string test = textBox1.Text.Substring(textBox1.Text.Length - 1,textBox1.Text.Length);
            txtString += test;
        }
        
        private void btnNum2_Click(object sender, EventArgs e)
        {
            textBox1.Text += "2";
            txtString += textBox1.Text;
        }

        private void btnNum3_Click(object sender, EventArgs e)
        {
            textBox1.Text += "3";
            txtString += textBox1.Text;
        }

        private void btnNum4_Click(object sender, EventArgs e)
        {
            textBox1.Text += "4";
            txtString += textBox1.Text;
        }

        private void btnNum5_Click(object sender, EventArgs e)
        {
            textBox1.Text += "5";
            txtString += textBox1.Text;
        }

        private void btnNum6_Click(object sender, EventArgs e)
        {
            textBox1.Text += "6";
            txtString += textBox1.Text;
        }

        private void btnNum7_Click(object sender, EventArgs e)
        {
            textBox1.Text += "7";
            txtString += textBox1.Text;
        }

        private void btnNum8_Click(object sender, EventArgs e)
        {
            textBox1.Text += "8";
            txtString += textBox1.Text;
        }

        private void btnNum9_Click(object sender, EventArgs e)
        {
            textBox1.Text += "9";
            txtString += textBox1.Text;
        }

        private void btnNum0_Click(object sender, EventArgs e)
        {
            textBox1.Text += "0";
            txtString += textBox1.Text;
        }

        private void btnDot_Click(object sender, EventArgs e)
        {
            textBox1.Text += ".";
            txtString += textBox1.Text;
        }

        #endregion

        private void btnScanner_Click(object sender, EventArgs e)
        {
            Button btnName = sender as Button;

            #region 사칙연산 클릭 시 해당 문자열 저장

            if(btnName == btnPlus)
            {
                txtString += "+";
            }
            else if(btnName == btnMinus)
            {
                txtString += "-";
            }
            else if(btnName == btnMultiply)
            {
                txtString += "*";
            }
            else if(btnName == btnDivision)
            {
                txtString += "/";
            }

            textBox1.Text = "";

            #endregion

        }

        private void btnMemory_Click(object sender, EventArgs e)
        {
            Button btnName = sender as Button;

            #region 메모리 저장 및 연산

            if(btnName == btnMS)
            {
                memoryString = txtString;
            }
            else if(btnName == btnMC)
            {
                memoryString = String.Empty;
                txtString = String.Empty;
                textBox1.Text = "";
            }
            else if(btnName == btnMPlus)
            {
                memoryString += "+" + textBox1.Text;
            }
            else if(btnName == btnMMinus)
            {
                memoryString += "-" + textBox1.Text;
            }
            else if(btnName == btnMR)
            {
                //계산 후 textbox 표시
            }

            #endregion

        }

        private void btnBackspace_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text.Substring(0, textBox1.Text.Length - 1);
            //substring : 어디서부터 몇개의 글자를 표시
            //텍스트 박스의 맨 앞~ 맨 마지막 바로 앞 까지만 입력
        }
        
        private void btnClear_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
        }

        private void btnCE_Click(object sender, EventArgs e)
        {
            txtString = txtString.Substring(0, textBox1.Text.Length);
            textBox1.Text = "";
        }


     
       
    }
}
